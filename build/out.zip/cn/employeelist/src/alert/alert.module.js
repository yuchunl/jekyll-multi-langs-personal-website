// Define the 'alert' module
angular.module('alert', []);