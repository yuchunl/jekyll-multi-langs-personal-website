// Register 'alert' component, along with its associated controller and template
angular.module('alert').component('alert', {
    templateUrl: 'src/alert/alert.template.html',
    controller: function alertController() {
    }
});