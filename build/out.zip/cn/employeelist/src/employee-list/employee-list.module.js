// Define the 'employeeList' module
angular.module('employeeList', []);